import { config } from 'dotenv';
config();

import '@/ai/flows/personalized-property-recommendations.ts';
import '@/ai/flows/generated-property-summaries.ts';