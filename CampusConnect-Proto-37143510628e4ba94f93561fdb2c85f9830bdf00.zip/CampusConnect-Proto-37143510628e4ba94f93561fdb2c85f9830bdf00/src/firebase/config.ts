export const firebaseConfig = {
  "projectId": "studio-3229930454-e80fa",
  "appId": "1:156650538348:web:fd6b07ff3e6dac7e2ddf49",
  "apiKey": "AIzaSyDiYRrAv0OyhKMNfLt7mkFMeXgaoHeMBmI",
  "authDomain": "studio-3229930454-e80fa.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "156650538348"
};
